# Directory Traversal Exploit

## Contents
HTTP Server with directory traversal exploit can be found runtimedir/insecure.py
HTTP Server with input validation can be found runtimedir/secure.py
Testing script can be found runtimedir/exploit.sh

## Running Instructions
- Navigate to runtimedir
- Run command ./exploit.sh
