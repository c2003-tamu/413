gdb -q -x findmain.py hw
