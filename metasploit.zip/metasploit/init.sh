docker pull metasploitframework/metasploit-framework
docker run -it metasploitframework/metasploit-framework /bin/bash
